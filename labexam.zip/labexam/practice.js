const { response } = require("express");
const express = require("express");
const { request } = require("http");
const Computer = require("./model.js");
const app = express();

app.use(express.urlencoded({extended:true}));
app.set("view engine","ejs");

app.get("/",async(request,response)=>{
    const computers = await Computer.find({});
    response.render("index.ejs",{computers})
});

app.get("/addcomputer",(request,response)=>{
    response.render("addcomputer.ejs")
});

app.post("/savecomputer",async(request,response)=>{
    const newComputer = new Computer(request.body);
    await newComputer.save();
    response.redirect("/")
});

app.post("/updatecomputer:id",async(request,response)=>{
    const updatecomputer = await Computer.findByIdAndUpdate(request.params.id,request.body);
    response.redirect("/")
});
app.listen(2324,()=>{
    console.log("Server Listetening at http://localhost:2324")
});
