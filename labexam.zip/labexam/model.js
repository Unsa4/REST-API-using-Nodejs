const mongoose = require("mongoose");
const compsh = new mongoose.Schema({
    title : String,
    CPU : String,
    Memory : Number,
    Storage: Number
})

module.exports = mongoose.model("Computer", compsh);